[Tonicblog Theme for PencilBlue](http://pencilblue.org)
=====

##### A PencilBlue blogger theme with thumbnail article sidebar.

Installation and Setup
-----

1. Clone the tonicblog-pencilblue repository into the plugins folder of your PencilBlue installation

```shell
   cd [pencilblue_directory]/plugins
   git clone https://github.com/raga2560/tonicblog-pencilblue

```

2. Install the tonicblog-pencilblue plugin through the manage plugins screen in the admin section (/admin/plugins).

3. Activate the Tonicblog Theme through the manage themes screen in the admin section.

4. Go to the tonicblog-pencilblue settings screen (/admin/plugins/settings/tonicblog-pencilblue) and set the theme and home page settings.

5. Load the main page of your PencilBlue website.




**Foundation**

- This theme is built using Devblog theme and Portfolio theme. 
- 1) Added related article list based on topics. 
- 2) Added thumbnail images to articles
- 3) Fixed bugs while listing articles.


**Usage**

- This theme is under development. 
- New features will be added shortly.
