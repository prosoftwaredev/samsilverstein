[Devblog Theme for PencilBlue](http://pencilblue.org)
=====

##### A PencilBlue theme built with a developer blog in mind.

Installation and Setup
-----

1. Clone the devblog-pencilblue repository into the plugins folder of your PencilBlue installation
```shell
cd [pencilblue_directory]/plugins
git clone https://github.com/pencilblue/devblog-pencilblue.git
```

2. Install the devblog-pencilblue plugin through the manage plugins screen in the admin section (/admin/plugins).

3. Activate the Devblog Theme through the manage themes screen in the admin section.

4. Go to the devblog-pencilblue settings screen (/admin/plugins/settings/devblog-pencilblue) and set the theme and home page settings.

5. Load the main page of your PencilBlue website.
